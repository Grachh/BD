
public interface ICurso {

	public String getNombreCurso();

	public void setNombreCurso(String nombreSec);
	
}
