import java.util.List;

public interface IProfesorDAO {
	public boolean registrar(IProfesor cliente);
	public List<IProfesor> obtener();
	public boolean actualizar(IProfesor prof);
	public boolean eliminar(IProfesor prof);
	public void listarResultados(List<IProfesor> ListProf);
}
