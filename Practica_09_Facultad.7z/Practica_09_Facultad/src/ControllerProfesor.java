import java.util.List;

public class ControllerProfesor {
	
	public ControllerProfesor() {
	}
	
	//llama al DAO para guardar un cliente
	public boolean registrar(IProfesor profesor ) {
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.registrar(profesor);
	}
	
	public List<IProfesor> obtener(){
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.obtener();
	}
	
	public void listarResultados(List<IProfesor> ListProf) {
		IProfesorDAO dao= new ProfesorDaoImp();
		dao.listarResultados(ListProf);
	}
	
	public boolean actualizar(IProfesor prof) {
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.actualizar(prof);
	}
	
	public boolean eliminar(IProfesor prof) {
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.eliminar(prof);
	}
}
